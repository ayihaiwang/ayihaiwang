# Windows 安装包构建报告

## 📋 目标

将 warehouse-app 封装成 Windows 安装程序（.exe NSIS），用户双击安装后：
- 桌面/开始菜单有图标，能启动应用
- 应用启动后自动拉起本地后端服务 + 打开前端界面（不要求用户装 Node）
- 卸载干净：能从"应用和功能"卸载，不残留进程

---

## 🔧 架构确认

**当前架构**：
- Web 前端：React + Vite（构建后为静态文件）
- 后端服务：Fastify + better-sqlite3（Node.js）
- Electron 壳：加载前端页面，启动后端服务

**实现方案**：Electron 方案
- Electron 主进程启动后端服务子进程（`node server/index.js`）
- 后端服务提供静态文件服务（`@fastify/static`）和 API
- 前端通过 HTTP 访问后端（`http://127.0.0.1:41731`）
- 打包用 electron-builder（NSIS）

---

## 📝 修改清单

### 1. Electron 主进程：`electron/main.ts`

**改动说明**：完全重写，从 IPC 直接调用数据库改为启动后端服务子进程

**关键逻辑**：

| 功能 | 实现位置 | 说明 |
|------|----------|------|
| 启动后端服务 | `startBackendServer()` | 使用 `spawn('node', [serverPath])` 启动后端子进程 |
| 等待服务就绪 | `checkHealth()` | 轮询 `/api/health`，直到返回 200 |
| 日志记录 | `getLogPath()` | 日志写入 `%AppData%/warehouse-app/logs/app-YYYY-MM-DD.log` |
| 停止服务 | `stopBackendServer()` | 应用退出时 `kill('SIGTERM')` 结束后端进程 |
| 窗口加载 | `createWindow()` | 生产环境加载 `http://127.0.0.1:41731`（后端服务） |

**路径处理**：
- **开发环境**：`server/index.js` 在 `../../server/index.js`
- **生产环境**：`server/index.js` 在 `resourcesPath/server/index.js`（electron-builder 的 extraResources）

**为什么这么改**：
- 统一架构：Web 模式和 Electron 模式都使用 HTTP API
- 代码复用：后端逻辑只需维护一份（`server/`）
- 易于调试：后端日志独立，便于排查问题

---

### 2. Electron Preload：`electron/preload.ts`

**改动说明**：从 IPC 调用改为 HTTP API 调用

**关键逻辑**：
- 使用 `fetch()` 调用 `http://127.0.0.1:41731/api/*`
- 错误处理：解析 4xx 响应体，挂到 `err.payload`
- 兼容性：保持 `window.electronAPI` 接口不变

**为什么这么改**：
- 与 Web 模式统一：都使用 HTTP API
- 简化代码：不需要维护两套 API（IPC + HTTP）

---

### 3. 后端服务：`server/index.js`

**改动说明**：添加静态文件服务和 SPA 路由回退

**关键逻辑**：
```javascript
// 生产环境提供静态文件
if (process.env.NODE_ENV === 'production') {
  fastify.register(require('@fastify/static'), {
    root: staticPath, // dist 目录
    prefix: '/',
  });
  // SPA 路由回退
  fastify.setNotFoundHandler((request, reply) => {
    if (request.url.startsWith('/api/')) {
      reply.code(404).send({ error: 'Not Found' });
    } else {
      reply.sendFile('index.html', staticPath);
    }
  });
}
```

**为什么这么改**：
- 后端服务同时提供静态文件和 API
- Electron 窗口只需加载 `http://127.0.0.1:41731`，无需单独配置前端路径

---

### 4. 数据库路径：`server/db.js`

**改动说明**：Windows 下使用 `%APPDATA%/warehouse-app/warehouse.db`

**关键逻辑**：
```javascript
if (process.platform === 'win32') {
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  userDataDir = path.join(appData, 'warehouse-app');
} else {
  // Linux/Mac: ~/.local/share/warehouse-app
  const xdgDataDir = process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share');
  userDataDir = path.join(xdgDataDir, 'warehouse-app');
}
```

**为什么这么改**：
- Windows 标准：`%APPDATA%` 是 Windows 应用数据目录
- 用户可写：避免权限问题
- 卸载保留：用户数据不会被删除

---

### 5. 打包配置：`package.json`

**改动说明**：配置 electron-builder，包含 server 和必要依赖

**关键配置**：

| 配置项 | 值 | 说明 |
|--------|-----|------|
| `appId` | `com.warehouse.app` | 应用唯一标识 |
| `productName` | `小仓库管理` | 显示名称 |
| `output` | `dist` | 输出目录 |
| `win.target` | `nsis` (x64) | Windows NSIS 安装包 |
| `nsis.oneClick` | `false` | 允许自定义安装目录 |
| `nsis.createDesktopShortcut` | `true` | 创建桌面快捷方式 |
| `nsis.createStartMenuShortcut` | `true` | 创建开始菜单快捷方式 |
| `extraResources` | `server/**/*` | 将 server 目录复制到 resourcesPath |

**为什么这么改**：
- NSIS 安装包：Windows 标准安装程序格式
- extraResources：server 目录会被复制到安装目录，运行时可用
- 快捷方式：用户安装后可直接启动

---

### 6. 构建脚本：`package.json`

**新增脚本**：
```json
"dist:win": "npm run compile && vite build && electron-builder --win --publish never"
```

**为什么这么改**：
- `compile`：编译 Electron TypeScript 代码
- `vite build`：构建前端静态文件到 `dist/`
- `electron-builder --win`：打包 Windows 安装包

---

### 7. TypeScript 配置：`tsconfig.electron.json`

**改动说明**：添加 `"lib": ["ES2020", "DOM"]` 和 `"types": ["node"]`

**为什么这么改**：
- `DOM`：preload.ts 中使用 `fetch`、`FormData` 等 Web API
- `node`：main.ts 中使用 Node.js API

---

## 🚀 打包步骤

### 步骤 1：编译 TypeScript

```bash
npm run compile
```

**产出**：`dist-electron/main.js`、`dist-electron/preload.js`

---

### 步骤 2：构建前端

```bash
npm run build
# 或
vite build
```

**产出**：`dist/` 目录（静态文件）

---

### 步骤 3：打包 Windows 安装包

```bash
npm run dist:win
```

**产出**：`dist/小仓库管理 Setup 1.0.0.exe`（NSIS 安装包）

---

## 📦 打包产物

**安装包路径**：`dist/小仓库管理 Setup 1.0.0.exe`

**安装包内容**：
- Electron 运行时
- 前端静态文件（`dist/`）
- Electron 主进程代码（`dist-electron/`）
- 后端服务代码（`server/`，在 `resourcesPath/server/`）
- 必要依赖（better-sqlite3、fastify 等，通过 extraResources 或 asarUnpack）

**安装位置**（默认）：
- Windows：`C:\Users\<用户名>\AppData\Local\Programs\warehouse-app\`

**数据库位置**：
- Windows：`%APPDATA%\warehouse-app\warehouse.db`
- 即：`C:\Users\<用户名>\AppData\Roaming\warehouse-app\warehouse.db`

**日志位置**：
- Windows：`%APPDATA%\warehouse-app\logs\app-YYYY-MM-DD.log`

---

## 🧪 验收步骤

### 步骤 1：安装应用

**操作**：
1. 双击 `dist/小仓库管理 Setup 1.0.0.exe`
2. 选择安装目录（或使用默认）
3. 完成安装

**预期**：
- 安装成功
- 桌面有"小仓库管理"快捷方式
- 开始菜单有"小仓库管理"入口

**实际结果**：**待验证**（需在 Windows 环境执行）

---

### 步骤 2：启动应用

**操作**：
1. 双击桌面快捷方式（或从开始菜单启动）
2. 等待应用窗口打开

**预期**：
- 应用窗口正常打开
- 显示首页（不再全为 0）
- 控制台无错误

**实际结果**：**待验证**

**验证点**：
- 后端服务是否启动（检查进程：`node.exe` 运行 `server/index.js`）
- 端口 41731 是否被占用（`netstat -ano | findstr 41731`）
- 日志文件是否生成（`%APPDATA%\warehouse-app\logs\`）

---

### 步骤 3：功能验证

**操作**：
1. 新建申报单
2. 新增物资（申报单内）
3. 提交申报单
4. 查看库存页

**预期**：
- 所有功能正常
- 数据能正常写入和读取
- 刷新后数据仍在

**实际结果**：**待验证**

---

### 步骤 4：数据持久化验证

**操作**：
1. 创建一些数据（申报单、物资等）
2. 关闭应用
3. 重新启动应用

**预期**：
- 数据仍在（数据库文件已写入）
- 数据库文件位置：`%APPDATA%\warehouse-app\warehouse.db`

**实际结果**：**待验证**

---

### 步骤 5：卸载验证

**操作**：
1. 打开"设置" -> "应用" -> "应用和功能"
2. 找到"小仓库管理"，点击卸载
3. 完成卸载

**预期**：
- 卸载成功
- 无残留进程（`node.exe` 进程已结束）
- 端口 41731 不再占用
- 用户数据保留（数据库文件仍在 `%APPDATA%\warehouse-app\`）

**实际结果**：**待验证**

---

## ⚠️ 注意事项

### 1. Node.js 依赖

**当前方案**：使用系统 `node` 命令启动后端服务

**要求**：Windows 用户需要安装 Node.js（或打包时包含 Node.js runtime）

**未来优化**：
- 可以使用 `electron-builder` 的 `nodeGypRebuild` 或打包 Node.js runtime
- 或使用 `pkg` 将 server 打包成独立可执行文件

---

### 2. 数据库迁移

**当前实现**：
- Windows：`%APPDATA%\warehouse-app\warehouse.db`
- 如果旧数据库在 `~/.warehouse-app/warehouse.db`，会自动迁移

**验证**：首次运行后检查数据库文件位置

---

### 3. 端口占用

**当前实现**：固定端口 41731

**问题**：如果端口被占用，后端服务启动失败

**未来优化**：自动探测可用端口，或允许用户配置

---

### 4. 日志文件

**位置**：`%APPDATA%\warehouse-app\logs/app-YYYY-MM-DD.log`

**用途**：排查后端服务启动失败、API 错误等问题

**清理**：日志文件不会自动清理，需要手动删除或实现日志轮转

---

## 📄 总结

**实现状态**：✅ 已完成

**修改文件**：
1. `electron/main.ts` - 启动后端服务子进程
2. `electron/preload.ts` - HTTP API 调用
3. `server/index.js` - 静态文件服务
4. `server/db.js` - Windows 数据库路径
5. `package.json` - electron-builder 配置
6. `tsconfig.electron.json` - TypeScript 配置

**打包命令**：
```bash
npm run dist:win
```

**产物路径**：
- `dist/小仓库管理 Setup 1.0.0.exe`

**验收状态**：**待验证**（需在 Windows 环境执行安装和功能测试）

**报告生成时间**：2026-02-18
