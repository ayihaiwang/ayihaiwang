import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import ExcelJS from 'exceljs';
import type { StockRow } from '../vite-env.d';
import { downloadPdfAsFile } from './pdfDownload';
import { getInventoryExportColumnWidths, getInventoryExportWidthPercentages, EXPORT_COLUMN_KEYS } from './inventoryColumnWidths';
import { getInventoryFileName } from './exportFileName';

const INVENTORY_COLUMN_TITLES: Record<string, string> = {
  name: '物资名称',
  category_name: '物品分类',
  spec: '规格型号',
  unit: '单位',
  qty: '当前数量',
  min_stock: '最低预警',
  last_in_date: '最近入库日期',
  updated_at: '更新时间',
};


export function exportInventoryToPDF(list: StockRow[], companyName = '') {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const mainTitle = (companyName || '').trim() ? `${companyName.trim()}库存总表` : '库存总表';
  const pcts = getInventoryExportWidthPercentages();
  const colStyles = pcts.map((p, i) => `.col-${i} { width: ${p.toFixed(2)}%; }`).join('\n        ');
  const headerCells = EXPORT_COLUMN_KEYS.map((key, i) => `<th class="col-${i}">${INVENTORY_COLUMN_TITLES[key]}</th>`).join('');
  const rows = list.map(
    (row) =>
      `<tr>
        <td class="col-0">${row.name || ''}</td>
        <td class="col-1">${row.category_name ?? ''}</td>
        <td class="col-2">${row.spec ?? ''}</td>
        <td class="col-3">${row.unit || ''}</td>
        <td class="col-4">${row.qty ?? ''}</td>
        <td class="col-5">${row.min_stock ?? ''}</td>
        <td class="col-6">${row.last_in_date ?? ''}</td>
        <td class="col-7">${row.updated_at ?? ''}</td>
      </tr>`
  ).join('');

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${mainTitle}</title>
      <style>
        @page { size: A4; margin: 10mm; }
        body { font-family: Arial, "Microsoft YaHei", sans-serif; padding: 12px; font-size: 12px; }
        h1 { text-align: center; margin-bottom: 12px; font-size: 16px; font-weight: bold; }
        thead { display: table-header-group; }
        table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        th, td { border: 1px solid #333; padding: 4px 6px; text-align: left; }
        th { background-color: #f0f0f0; font-weight: bold; }
        ${colStyles}
        .footer { margin-top: 12px; font-size: 11px; color: #666; }
      </style>
    </head>
    <body>
      <h1>${mainTitle}</h1>
      <table>
        <thead><tr>${headerCells}</tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="footer">生成时间：${new Date().toLocaleString('zh-CN')} | 共 ${list.length} 条</div>
    </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.onload = () => {
    setTimeout(() => {
      html2canvas(printWindow.document.body, { scale: 2 }).then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= 297;

        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage('p', 'a4');
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          heightLeft -= 297;
        }

        downloadPdfAsFile(pdf, getInventoryFileName(companyName, new Date().toISOString().slice(0, 10), 'pdf'));
        printWindow.close();
      });
    }, 500);
  };
}

export async function exportInventoryToExcel(list: StockRow[], companyName = '') {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('库存总表', {
    views: [{ rightToLeft: false }],
    pageSetup: {
      orientation: 'portrait' as const,
      paperSize: 9,
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
      margins: { left: 0.6, right: 0.6, top: 0.75, bottom: 0.75, header: 0.3, footer: 0.3 },
      horizontalCentered: true,
    },
  });

  const borderThin = { style: 'thin' as const };
  const border = { top: borderThin, left: borderThin, bottom: borderThin, right: borderThin };

  const excelWidths = getInventoryExportColumnWidths();
  ws.columns = excelWidths.map((w) => ({ width: w }));

  const colCount = EXPORT_COLUMN_KEYS.length;
  const mainTitle = (companyName || '').trim() ? `${companyName.trim()}库存总表` : '库存总表';
  const titleRow = ws.getRow(1);
  titleRow.getCell(1).value = mainTitle;
  titleRow.getCell(1).font = { bold: true, size: 16 };
  titleRow.getCell(1).alignment = { horizontal: 'center' };
  ws.mergeCells(1, 1, 1, colCount);
  titleRow.height = 26;

  ws.getRow(2).getCell(1).value = '生成时间';
  ws.getRow(2).getCell(2).value = new Date().toLocaleString('zh-CN');
  ws.getRow(3).height = 6;

  const headerRowNum = 4;
  const headerRow = ws.getRow(headerRowNum);
  EXPORT_COLUMN_KEYS.forEach((key, i) => {
    const cell = headerRow.getCell(i + 1);
    cell.value = INVENTORY_COLUMN_TITLES[key];
    cell.border = border;
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8E8E8' } };
    cell.font = { bold: true };
  });
  headerRow.height = 22;

  const dataStartRow = 5;
  list.forEach((row, idx) => {
    const r = ws.getRow(dataStartRow + idx);
    EXPORT_COLUMN_KEYS.forEach((colKey, c) => {
      const cell = r.getCell(c + 1);
      let val: string | number = (row as any)[colKey] ?? '';
      const isNum = colKey === 'qty' || colKey === 'min_stock';
      const isDate = colKey === 'last_in_date' || colKey === 'updated_at';
      if (isNum) {
        const n = Number(val);
        cell.value = typeof val === 'number' || val === '' ? val : n;
        cell.numFmt = '0';
      } else {
        cell.value = String(val);
      }
      cell.border = border;
      cell.alignment = {
        vertical: 'middle',
        horizontal: isNum ? 'right' : isDate ? 'center' : 'left',
        wrapText: true,
      };
    });
    r.height = 18;
  });

  ws.views = [{ state: 'frozen' as const, ySplit: headerRowNum, activeCell: 'A5' }];
  ws.pageSetup.printTitlesRow = `${headerRowNum}:${headerRowNum}`;

  Object.assign(ws.pageSetup, {
    orientation: 'portrait' as const,
    paperSize: 9,
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: 0,
    margins: { left: 0.6, right: 0.6, top: 0.75, bottom: 0.75, header: 0.3, footer: 0.3 },
    horizontalCentered: true,
  });

  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = getInventoryFileName(companyName, new Date().toISOString().slice(0, 10), 'xlsx');
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 300);
}

export function printInventory(list: StockRow[], companyName = '') {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const mainTitle = (companyName || '').trim() ? `${companyName.trim()}库存总表` : '库存总表';
  const pcts = getInventoryExportWidthPercentages();
  const colStyles = pcts.map((p, i) => `.col-${i} { width: ${p.toFixed(2)}%; }`).join('\n        ');
  const headerCells = EXPORT_COLUMN_KEYS.map((key, i) => `<th class="col-${i}">${INVENTORY_COLUMN_TITLES[key]}</th>`).join('');
  const rows = list.map(
    (row) =>
      `<tr>
        <td class="col-0">${row.name || ''}</td>
        <td class="col-1">${row.category_name ?? ''}</td>
        <td class="col-2">${row.spec ?? ''}</td>
        <td class="col-3">${row.unit || ''}</td>
        <td class="col-4">${row.qty ?? ''}${row.min_stock > 0 && row.qty < row.min_stock ? ' (低于预警)' : ''}</td>
        <td class="col-5">${row.min_stock ?? ''}</td>
        <td class="col-6">${row.last_in_date ?? ''}</td>
        <td class="col-7">${row.updated_at ?? ''}</td>
      </tr>`
  ).join('');

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${mainTitle}</title>
      <style>
        @page { size: A4; margin: 10mm; }
        body { font-family: Arial, "Microsoft YaHei", sans-serif; padding: 12px; }
        h1 { text-align: center; margin-bottom: 12px; }
        table { width: 100%; border-collapse: collapse; table-layout: fixed; }
        th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        ${colStyles}
        .footer { margin-top: 16px; font-size: 12px; color: #666; }
        @media print { body { padding: 0; } }
      </style>
    </head>
    <body>
      <h1>${mainTitle}</h1>
      <table>
        <thead><tr>${headerCells}</tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="footer">生成时间：${new Date().toLocaleString('zh-CN')} | 共 ${list.length} 条</div>
    </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.onload = () => {
    printWindow.print();
  };
}
