import { app, BrowserWindow } from 'electron';
import * as path from 'path';
import { spawn, ChildProcess } from 'child_process';
import * as fs from 'fs';

const isDev = process.env.NODE_ENV !== 'production' || process.argv.includes('--dev');

// 后端服务进程
let backendProcess: ChildProcess | null = null;
const BACKEND_PORT = 41731;
const BACKEND_URL = `http://127.0.0.1:${BACKEND_PORT}`;

// 日志文件路径
function getLogPath(): string {
  const userData = app.getPath('userData');
  const logDir = path.join(userData, 'logs');
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  return path.join(logDir, `app-${new Date().toISOString().slice(0, 10)}.log`);
}

// 启动后端服务（使用 tsx 直接运行 TS）
function startBackendServer(): Promise<void> {
  return new Promise((resolve, reject) => {
    let serverEntry: string;
    let serverCwd: string;
    const tsxDir = path.dirname(require.resolve('tsx/package.json'));
    const tsxCli = path.join(tsxDir, 'dist/cli.mjs');

    if (isDev) {
      serverEntry = path.join(__dirname, '../../server/index.ts');
      serverCwd = path.join(__dirname, '../..');
    } else {
      const resourcesPath = process.resourcesPath || app.getAppPath();
      serverEntry = path.join(resourcesPath, 'server', 'index.ts');
      serverCwd = resourcesPath;
    }

    console.log('[Electron] 启动后端服务:', serverEntry);
    console.log('[Electron] 工作目录:', serverCwd);

    const env = {
      ...process.env,
      NODE_ENV: 'production',
      NODE_PATH: isDev ? undefined : serverCwd,
    };

    backendProcess = spawn(process.execPath, [tsxCli, serverEntry], {
      env,
      cwd: serverCwd,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const logPath = getLogPath();
    const logStream = fs.createWriteStream(logPath, { flags: 'a' });
    logStream.write(`\n=== 启动后端服务 ${new Date().toISOString()} ===\n`);

    backendProcess.stdout?.on('data', (data: Buffer) => {
      const msg = data.toString();
      console.log('[Backend]', msg);
      logStream.write(`[STDOUT] ${msg}`);
    });

    backendProcess.stderr?.on('data', (data: Buffer) => {
      const msg = data.toString();
      console.error('[Backend]', msg);
      logStream.write(`[STDERR] ${msg}`);
    });

    backendProcess.on('error', (err: Error) => {
      console.error('[Electron] 后端服务启动失败:', err);
      logStream.write(`[ERROR] ${err.message}\n`);
      logStream.end();
      reject(err);
    });

    backendProcess.on('exit', (code: number) => {
      console.log(`[Electron] 后端服务退出，代码: ${code}`);
      logStream.write(`[EXIT] 代码: ${code}\n`);
      logStream.end();
      backendProcess = null;
    });

    // 等待后端服务就绪
    const checkHealth = async (): Promise<void> => {
      try {
        const response = await fetch(`${BACKEND_URL}/api/health`);
        if (response.ok) {
          console.log('[Electron] 后端服务已就绪');
          logStream.end();
          resolve();
        } else {
          setTimeout(checkHealth, 500);
        }
      } catch (e) {
        setTimeout(checkHealth, 500);
      }
    };

    // 等待最多 30 秒
    setTimeout(() => {
      if (backendProcess && backendProcess.pid) {
        reject(new Error('后端服务启动超时'));
      }
    }, 30000);

    setTimeout(checkHealth, 1000);
  });
}

// 停止后端服务
function stopBackendServer() {
  if (backendProcess) {
    console.log('[Electron] 停止后端服务');
    backendProcess.kill('SIGTERM');
    backendProcess = null;
  }
}

let mainWindow: BrowserWindow | null = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    // icon 路径在生产环境可能不同，使用可选路径
    icon: fs.existsSync(path.join(__dirname, '../public/icon.ico'))
      ? path.join(__dirname, '../public/icon.ico')
      : undefined,
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    // 生产环境：后端服务提供静态文件和 API
    mainWindow.loadURL(BACKEND_URL);
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  try {
    await startBackendServer();
    createWindow();
  } catch (err) {
    console.error('[Electron] 启动失败:', err);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  stopBackendServer();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  stopBackendServer();
});

app.on('will-quit', () => {
  stopBackendServer();
});
