/**
 * 统一数据库连接管理
 */
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import os from 'os';

let db: Database.Database | null = null;

function getDbPath(): string {
  const userDataDir = path.join(os.homedir(), '.warehouse-app');
  if (!fs.existsSync(userDataDir)) {
    fs.mkdirSync(userDataDir, { recursive: true });
  }
  return path.join(userDataDir, 'warehouse.db');
}

export function initDb() {
  const dbPath = getDbPath();
  console.log(`📂 [DB] 数据库路径: ${dbPath}`);
  console.log(`📂 [DB] 数据库文件存在: ${fs.existsSync(dbPath) ? '是' : '否'}`);
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  console.log(`✅ [DB] 数据库连接已初始化（可写模式）`);
  return db;
}

export function getDbPathPublic(): string {
  return getDbPath();
}

export function getDb(): Database.Database {
  if (!db) {
    initDb();
  }
  if (!db) throw new Error('DB not initialized');
  return db;
}

export function close() {
  if (db) db.close();
  db = null;
}
